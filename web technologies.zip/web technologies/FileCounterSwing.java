import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class FileCounterSwing extends JFrame implements ActionListener {
    private JTextField fileField;
    private JButton countButton;
    private JTextArea resultArea;

    public FileCounterSwing() {
        setTitle("File Character, Word, and Line Counter");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        fileField = new JTextField();
        countButton = new JButton("Count");
        countButton.addActionListener(this);

        topPanel.add(new JLabel("Enter File Name:"), BorderLayout.WEST);
        topPanel.add(fileField, BorderLayout.CENTER);
        topPanel.add(countButton, BorderLayout.EAST);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(resultArea);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String fileName = fileField.getText().trim();
        if (fileName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a file name.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        File file = new File(fileName);
        if (!file.exists()) {
            JOptionPane.showMessageDialog(this, "File not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            int charCount = 0, wordCount = 0, lineCount = 0;
            String line;

            while ((line = br.readLine()) != null) {
                lineCount++;
                charCount += line.length();
                String[] words = line.trim().split("\\s+");
                if (!line.trim().isEmpty()) {
                    wordCount += words.length;
                }
            }

            resultArea.setText("File: " + fileName + "\n");
            resultArea.append("Characters: " + charCount + "\n");
            resultArea.append("Words: " + wordCount + "\n");
            resultArea.append("Lines: " + lineCount + "\n");

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new FileCounterSwing().setVisible(true);
        });
    }
}
