import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class CalculatorServlet extends HttpServlet {
    private Connection conn;

    public void init() throws ServletException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/calculator_db", "root", "yourpassword"
            );
        } catch (Exception e) {
            throw new ServletException("DB connection error: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        double num1 = Double.parseDouble(req.getParameter("num1"));
        double num2 = Double.parseDouble(req.getParameter("num2"));
        String op = req.getParameter("op");

        String expression = num1 + " " + op + " " + num2;
        double result = 0;

        try {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT result FROM calculations WHERE expression=?");
            ps.setString(1, expression);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                result = rs.getDouble(1);
            } else {
                switch (op) {
                    case "+": result = num1 + num2; break;
                    case "-": result = num1 - num2; break;
                    case "*": result = num1 * num2; break;
                    case "/": result = num2 != 0 ? num1 / num2 : Double.NaN; break;
                    case "%": result = num1 % num2; break;
                }

                PreparedStatement insert = conn.prepareStatement(
                    "INSERT INTO calculations(expression, result) VALUES(?, ?)");
                insert.setString(1, expression);
                insert.setDouble(2, result);
                insert.executeUpdate();
            }

            out.println("<h2>Result: " + expression + " = " + result + "</h2>");
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }

    public void destroy() {
        try {
            if (conn != null) conn.close();
        } catch (Exception e) {}
    }
}
