// Country → Capital data
const DATA = [
  { name: "India", code: "IN", capital: "New Delhi" },
  { name: "Switzerland", code: "CH", capital: "Bern" },
  { name: "Japan", code: "JP", capital: "Tokyo" },
  { name: "Brazil", code: "BR", capital: "Brasília" },
  { name: "Egypt", code: "EG", capital: "Cairo" }
];

const listEl = document.querySelector('#list .list');
const capitalEl = document.getElementById('capital');
const metaEl = document.getElementById('meta');

// Render list
DATA.forEach((item, idx) => {
  const li = document.createElement('li');
  li.innerHTML = `
    <label class="country" role="radio" aria-checked="${idx===0}" tabindex="0" data-index="${idx}">
      <span class="name">${item.name}</span>
      <span class="code">${item.code}</span>
      <input type="radio" name="country" ${idx===0? 'checked' : ''} />
    </label>
  `;
  listEl.appendChild(li);
});

function selectIndex(i) {
  document.querySelectorAll('.country').forEach((el, j) => {
    el.setAttribute('aria-checked', j === i);
  });
  const { name, capital } = DATA[i];
  capitalEl.textContent = capital;
  metaEl.textContent = `${capital} is the capital of ${name}.`;
}

// Default selection
selectIndex(0);

// Click handler
listEl.addEventListener('click', (e) => {
  const label = e.target.closest('.country');
  if (!label) return;
  selectIndex(+label.dataset.index);
});
