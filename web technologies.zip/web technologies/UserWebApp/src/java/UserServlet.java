import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class UserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String inputId = request.getParameter("userid");

        try {
            // Path to XML file inside WEB-INF
            String xmlPath = getServletContext().getRealPath("/WEB-INF/users.xml");

            File xmlFile = new File(xmlPath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("User");
            boolean found = false;

            out.println("<html><body>");
            for (int i = 0; i < nList.getLength(); i++) {
                Node nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element elem = (Element) nNode;
                    String userId = elem.getElementsByTagName("UserId").item(0).getTextContent();

                    if (userId.equals(inputId)) {
                        found = true;
                        String name = elem.getElementsByTagName("Name").item(0).getTextContent();
                        String email = elem.getElementsByTagName("Email").item(0).getTextContent();
                        String phone = elem.getElementsByTagName("Phone").item(0).getTextContent();

                        out.println("<h3>User Found:</h3>");
                        out.println("UserId: " + userId + "<br>");
                        out.println("Name: " + name + "<br>");
                        out.println("Email: " + email + "<br>");
                        out.println("Phone: " + phone + "<br>");
                        break;
                    }
                }
            }

            if (!found) {
                out.println("<h3>User with ID " + inputId + " not found!</h3>");
            }
            out.println("</body></html>");

        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
}
