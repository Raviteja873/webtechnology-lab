const ones = [
  "zero","one","two","three","four","five","six","seven","eight","nine",
  "ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"
];

const tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];

function numberToWords(n) {
  if (n < 20) return ones[n];
  if (n < 100) {
    const t = Math.floor(n / 10), r = n % 10;
    return tens[t] + (r ? "-" + ones[r] : "");
  }
  const h = Math.floor(n / 100);
  const r = n % 100;
  return ones[h] + " hundred" + (r ? " and " + numberToWords(r) : "");
}

function convert() {
  const input = document.getElementById('num').value.trim();
  const out = document.getElementById('words');

  if (input === "") { 
    out.value = ""; 
    return; 
  }

  // Ensure it's an integer
  const n = parseInt(input, 10);

  if (isNaN(n)) {
    out.value = "not a number";
    return;
  }

  if (n < 0 || n > 999) {
    out.value = "out of range";
    return;
  }

  out.value = numberToWords(n);
}

function clearAll() {
  document.getElementById('num').value = "";
  document.getElementById('words').value = "";
  document.getElementById('num').focus();
}
